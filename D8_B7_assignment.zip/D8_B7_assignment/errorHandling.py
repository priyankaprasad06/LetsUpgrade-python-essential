'''

text="“If people are doubting how far you can go, go so far that you can’t hear them anymore.” – Michele Ruiz"

'''
try:

    f=open('text.txt','r')
    a=f.write('my name is abhishek')
    #print(f.read())
    print(a)
    f.close()

except:
    print('ERROR: File is in read-only mode.')

