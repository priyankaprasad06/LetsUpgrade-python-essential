
def decorator(function):
   def wrapper(num):
        print("Inside wrapper to check odd/even")
        if num%2 == 0:
            nmbr= "Even"
        else:
            nmbr= "Odd!"
        function(num)        
        return nmbr
   print ("wrapper function is called")
   return wrapper

def myfunction(x):
    print("The number is=",x)
myfunction=decorator(myfunction)
no=int(input('Enter number: '))
print ("It is ",myfunction(no))