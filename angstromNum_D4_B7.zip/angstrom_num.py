
for num in range(1042000,702648265):

    order = len(str(num))
    sum = 0
    
    
    temp = num
    
    while(num>0):
        digit = num%10
        sum += digit**order
        num = num//10    
        
    
    if (sum==temp):
        print("The first armstrong number is: \n",sum)
        break


