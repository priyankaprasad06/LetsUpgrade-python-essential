
def prime_num(x):
    for n in range(2,x):
        if x%n==0:
            return False
        else:
            return True

fltr_Obj=filter(prime_num, range(2500))
print ('Prime numbers between 1-2500:\n', list(fltr_Obj))