lst = [input()]
lst_arg = map(lambda x: x.title(), lst)
print(list(lst_arg))
